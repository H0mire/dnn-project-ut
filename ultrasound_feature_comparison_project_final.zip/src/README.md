# Ultrasound Image Classification

This project compares two machine learning models for classifying ultrasound images of six organs:

- Bladder
- Kidney
- Liver
- Gallbladder
- Spleen
- Bowel

## 🧠 Models
1. **Convolutional Neural Network (CNN)**: Learns from image pixels.
2. **MLP on Handcrafted Features**: Uses histogram, Sobel edges, and statistics as input.

## 📁 Structure
```
ultrasound_feature_comparison_project/
├── datasets/
│   └── img/
│       ├── train/
│       └── test/
├── src/
│   ├── train_cnn.py
│   ├── train_mlp.py
│   ├── features.py
│   ├── evaluate.py
│   ├── main.py
│   ├── report.html
│   └── README.md
```

## 🚀 Run Training & Evaluation
```bash
cd src
python main.py
```

## 📊 Outputs
- Console logs of metrics (accuracy, precision, recall, F1)
- `report.html` with results and confusion matrices

## 📦 Requirements
- Python 3.8+
- PyTorch
- OpenCV
- scikit-learn
- matplotlib