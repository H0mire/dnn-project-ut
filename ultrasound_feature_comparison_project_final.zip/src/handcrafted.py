import cv2
import numpy as np

def extract_handcrafted_features(img):
    features = []
    hist = cv2.calcHist([img], [0], None, [32], [0, 256]).flatten()
    hist = hist / (hist.sum() + 1e-6)
    features.extend(hist)

    features.append(np.mean(img))
    features.append(np.std(img))

    sobelx = cv2.Sobel(img, cv2.CV_64F, 1, 0, ksize=3)
    sobely = cv2.Sobel(img, cv2.CV_64F, 0, 1, ksize=3)
    sobel_mag = np.sqrt(sobelx**2 + sobely**2)
    features.append(np.mean(sobel_mag))
    features.append(np.std(sobel_mag))

    return np.array(features, dtype=np.float32)