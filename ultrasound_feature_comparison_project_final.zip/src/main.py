import os
import torch
import numpy as np
import cv2
from torch import nn
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from handcrafted import extract_handcrafted_features
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

classes = ['bladder', 'kidney', 'liver', 'gallbladder', 'spleen', 'bowel']
img_size = 64

# Dataset class
class UltrasoundDataset(Dataset):
    def __init__(self, image_paths, labels, transform=None, use_handcrafted=False):
        self.image_paths = image_paths
        self.labels = labels
        self.transform = transform
        self.use_handcrafted = use_handcrafted

    def __len__(self):
        return len(self.image_paths)

    def __getitem__(self, idx):
        img_path = self.image_paths[idx]
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, (img_size, img_size))
        label = self.labels[idx]

        if self.use_handcrafted:
            features = extract_handcrafted_features(img)
            return torch.tensor(features, dtype=torch.float32), label
        else:
            if self.transform:
                img = self.transform(img)
            return img, label

# CNN model
class SimpleCNN(nn.Module):
    def __init__(self, num_classes):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 8, kernel_size=5, padding=2)
        self.conv2 = nn.Conv2d(8, 16, kernel_size=3, padding=1)
        self.pool = nn.MaxPool2d(2, 2)
        self.fc1 = nn.Linear(16 * 16 * 16, 64)
        self.fc2 = nn.Linear(64, num_classes)

    def forward(self, x):
        x = self.pool(torch.relu(self.conv1(x)))
        x = self.pool(torch.relu(self.conv2(x)))
        x = x.view(-1, 16 * 16 * 16)
        x = torch.relu(self.fc1(x))
        return self.fc2(x)

# MLP for handcrafted features
class HandcraftedMLP(nn.Module):
    def __init__(self, input_dim, num_classes):
        super(HandcraftedMLP, self).__init__()
        self.fc1 = nn.Linear(input_dim, 64)
        self.fc2 = nn.Linear(64, num_classes)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        return self.fc2(x)

# Utility functions
def load_data(data_dir, class_list):
    paths, labels = [], []
    for i, cls in enumerate(class_list):
        folder = os.path.join(data_dir, cls)
        for fname in os.listdir(folder):
            if fname.endswith(".png"):
                paths.append(os.path.join(folder, fname))
                labels.append(i)
    return paths, labels

def train(model, loader, criterion, optimizer):
    model.train()
    for x, y in loader:
        optimizer.zero_grad()
        outputs = model(x)
        loss = criterion(outputs, y)
        loss.backward()
        optimizer.step()

def evaluate(model, loader):
    model.eval()
    y_true, y_pred = [], []
    with torch.no_grad():
        for x, y in loader:
            outputs = model(x)
            _, preds = torch.max(outputs, 1)
            y_true.extend(y.numpy())
            y_pred.extend(preds.numpy())
    return np.array(y_true), np.array(y_pred)

def report(title, y_true, y_pred):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, average='macro')
    rec = recall_score(y_true, y_pred, average='macro')
    f1 = f1_score(y_true, y_pred, average='macro')
    print(f"=== {title} ===")
    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {prec:.4f}")
    print(f"Recall   : {rec:.4f}")
    print(f"F1 Score : {f1:.4f}")
    ConfusionMatrixDisplay(confusion_matrix(y_true, y_pred), display_labels=classes).plot(cmap='Blues')
    plt.title(f"Confusion Matrix - {title}")
    plt.show()

# Main execution
def main():
    transform = transforms.Compose([transforms.ToTensor()])
    train_dir = "./datasets/img/train"
    test_dir = "./datasets/img/test"
    X_train, y_train = load_data(train_dir, classes)
    X_test, y_test = load_data(test_dir, classes)

    # CNN
    train_ds = UltrasoundDataset(X_train, y_train, transform, use_handcrafted=False)
    test_ds = UltrasoundDataset(X_test, y_test, transform, use_handcrafted=False)
    train_loader = DataLoader(train_ds, batch_size=8, shuffle=True)
    test_loader = DataLoader(test_ds, batch_size=8, shuffle=False)

    cnn = SimpleCNN(num_classes=len(classes))
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(cnn.parameters(), lr=0.001)

    for _ in range(10):
        train(cnn, train_loader, criterion, optimizer)

    y_true, y_pred = evaluate(cnn, test_loader)
    report("CNN", y_true, y_pred)

    # Handcrafted MLP
    train_ds = UltrasoundDataset(X_train, y_train, None, use_handcrafted=True)
    test_ds = UltrasoundDataset(X_test, y_test, None, use_handcrafted=True)
    train_loader = DataLoader(train_ds, batch_size=8, shuffle=True)
    test_loader = DataLoader(test_ds, batch_size=8, shuffle=False)

    feature_dim = len(train_ds[0][0])
    mlp = HandcraftedMLP(input_dim=feature_dim, num_classes=len(classes))
    optimizer = torch.optim.Adam(mlp.parameters(), lr=0.001)

    for _ in range(10):
        train(mlp, train_loader, criterion, optimizer)

    y_true, y_pred = evaluate(mlp, test_loader)
    report("Handcrafted MLP", y_true, y_pred)

if __name__ == "__main__":
    main()